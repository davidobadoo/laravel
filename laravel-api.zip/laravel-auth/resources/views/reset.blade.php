<a href="localhost:8000/reset/{{$token}}">Reset Password</a>
